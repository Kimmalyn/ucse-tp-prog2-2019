﻿namespace Contratos
{
    public class Padre : Usuario
    {
        public Hijo[] Hijos { get; set; }
    }
}