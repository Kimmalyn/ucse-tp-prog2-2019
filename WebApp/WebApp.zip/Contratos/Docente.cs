﻿namespace Contratos
{
    public class Docente : Usuario
    {
        public Sala[] Salas { get; set; }
    }
}