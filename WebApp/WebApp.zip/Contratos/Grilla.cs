﻿namespace Contratos
{
    public class Grilla<T>
    {
        public T[] Lista { get; set; }
        public int CantidadRegistros { get; set; }
    }
}